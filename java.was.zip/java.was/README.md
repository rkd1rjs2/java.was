

1. HTTP/1.1 의 Host 헤더를 해석하세요. (Header 생성시 구현)
2. 설정 파일로 관리하세요. (application.json servers 로 관리)
3. 403, 404, 500 에러를 처리 (HttpHandler 구현)
4. 보안 규칙 (ConfigModule.checkBlockedExtension 구현)
5. logback 프레임워크 (logback.xml 구현)
6. SimpleServlet 구현 
7. 현재 시각을 출력 (Time 구현)
8. JUnit4 를 이용한 테스트 케이스 (SimpleTest 구현)
