package com.test;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.simple.JSONObject;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.was.HttpServer;

public class SimpleTest {
	private static Logger logger = LoggerFactory.getLogger(HttpServer.class);

	@Test
	public void test() {

		String[] testUrl = { 
				"http://localhost:8000",
				"http://localhost:8000/passwd.exe",
				"http://localhost:8000/../../../../etc/passwd",
				"http://localhost:8000/Hello",
				"http://localhost:8000/Time",
				"http://localhost:8000/service.Hello",
				"http://www.server2.com"
				};
		
		HttpURLConnection conn = null;
		try {

			for (String urlStr : testUrl) {

				URL url = new URL(urlStr);

				conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Content-Type", "application/json");
				conn.setRequestProperty("Transfer-Encoding", "chunked");
				conn.setRequestProperty("Connection", "keep-alive");
				conn.setDoOutput(true);

				// 보내고 결과값 받기
				int responseCode = conn.getResponseCode();
				if (responseCode == 200) {
					BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
					StringBuilder sb = new StringBuilder();
					String line = "";
					while ((line = br.readLine()) != null) {
						sb.append(line);
					}

					// 응답 데이터
					logger.info("responseResult :: " + sb.toString());
				} else {
					logger.info("responseException :: " + urlStr);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
