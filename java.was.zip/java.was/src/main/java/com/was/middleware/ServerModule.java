package com.was.middleware;

import java.util.*;
import com.typesafe.config.*;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.was.middleware.Class.Server;

public class ServerModule {
    private Map<String, Server> srvs = new HashMap<String, Server>();
    private Server defaultServer;

    public ServerModule(List<? extends Config> servers)
        throws IllegalAccessException, ParseException {
        for(Config cv : servers) {
            Server srv = new Server(cv.getString("server_name"));
            srv.setDomain(cv.getString("domain"));
            srv.setHttproot(cv.getString("http_root"));
            srv.setSource(cv.getConfig("source"));

            srvs.put(srv.getName(), srv);
        }
    }

    public Server getDefaultServer() {
        return this.defaultServer;
    }

    public void setDefaultServer(String srvName) {
        Server srv = srvs.get(srvName);
        this.defaultServer = srv;
    }

    public Server getServer(String srvName) {
        Server srv = srvs.get(srvName);
        return srv;
    }
    public Map<String, Server> getServer() {
        return srvs;
    }

    public void setDefaultServerDomain(String domain) {
        if(!this.getDefaultServer().getDomain().equals(domain)) {
            for( Map.Entry<String, Server> srv : srvs.entrySet() ){
                if(srv.getValue().getDomain().equals(domain))
                    this.defaultServer = srv.getValue();
            }
        }
    }

    public Integer getServerCount() {
        return srvs.size();
    }
}